
Cavernous LITE
=======
Cavernous Lite is a rebuilt version of Cavernous that will be much more compatible with other mods and datapacks. Cavernous Lite is NOT backwards compatible with any previous versions of Cavernous.

New Biomes
=======
- Fungal Caves
  - These caves are full of all sorts of mushrooms, some even growing down from the ceiling!
- Volcanic Caves
  - These caves found at the bottom of your world contain even more diamonds than a usual cave biome. However, they are incredibly difficult to traverse due to the lava rivers that flow throughout them so weight the risk and reward carefully!
- Crystal Caves
  - Full of amethyst geodes and the faint glow of amethyst crystals, these caves are certainly a sight to behold.
- Arid Caves
  - These caves generate under deserts, savannas, and badlands, and resemble a barren wasteland. Try to mine the extra gold that generates in this biome and watch out for falling sand!
- Buried Jungle
- Icy Caves
  - If you thought regular caving was hard, try looking for ores under ice! In this biome that's what you'll have to do since no ores generate on the floor's surface, you'll have to catch a glimpse through the ice to find what you're looking for.
- Marbled Caves
- Lush Dripstone Caves


Future Additions:
============
I plan to eventually add back almost everything that doesn't involve datapack driven custom items or features. Some things may come back exactly how they were before, some may change, and there might be new things along the way.

- Advancements
- Structures
- More advanced worldgen features
  - Removing aquifers in certain biomes in a way that's compatible with other mods.
- Mob spawns in biomes (ex: strays in icy caves)
  - This one is saved for later since I'll probably have to do it differently for the mod and datapack side of things.
